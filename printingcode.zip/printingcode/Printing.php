<?php
if(!empty($_GET['id'])){
    $IdOfBilling = $_GET['id'];

    // dito ang query .......................
}

?>